import mongoose from "mongoose";

const StudentSchema = new mongoose.Schema(
  {
    registrationNo: {
      type: String,
      required: true,
      unique: true, 
    },
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true, 
      match: [/^\S+@\S+\.\S+$/, "Please enter a valid email address"],
    },
    password: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      enum: ["student", "technical_secretary", "sports_secretary", "general_secretary", "girls_representative", "cultural_secretary"],
      default: "student",
    },
    department: {
      type: String,
      enum: ["CSE", "IT", "EXTC", "INST", "ELE", "CHE", "CIVIL", "MECH", "PROD", "TEXT"],
      required: true, 
    },
    year: {
      type: Number,
    },
    phone: {
      type: String,
      required: false,
    //   match: [/^\d{10}$/, "Please enter a valid 10-digit phone number"],
    },
    dob: {
      type: Date,
      required: false,
    },
    address: {
      type: String,
    },
  },
  { timestamps: true }
);

const Student = mongoose.model("Student", StudentSchema);
export default Student;
