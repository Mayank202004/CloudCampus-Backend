import mongoose from "mongoose";

const CheatingRecordSchema = new mongoose.Schema(
  {
    student: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Student",
      required: true,
    },
    registrationNo: {
      type: String,
      required: true,
      trim: true,
    },
    examName: {
      type: String,
      required: true,
      trim: true,
    },
    subject: {
      type: String,
      required: true,
      trim: true,
    },
    cheatingReason: {
      type: String,
      required: true,
      trim: true,
    },
    proof: [
      {
        type: String, // Can store URLs to uploaded image or document proofs
        trim: true,
      },
    ],
    caughtBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Faculty",
      required: true,
    },
    caughtByName: {
      type: String,
      required: true,
      trim: true,
    },
    visibility: {
      type: String,
      enum: ["Public", "Faculty-Only", "Private"],
      default: "Public",
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

const CheatingRecord = mongoose.model("CheatingRecord", CheatingRecordSchema);
export default CheatingRecord;
